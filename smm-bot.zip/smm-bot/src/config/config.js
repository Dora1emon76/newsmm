module.exports = {
  // Telegram bot token for authentication and authorization
  bot_token: `6776263808:AAHMsYQIZxcWF3byOTSYdry0IR6k4oFfzXg`,

  // Telegram ID of the owner
  owner: `6371794184`,

  // Firebase Realtime Database URL
  database_url: `https://rocoproc-default-rtdb.firebaseio.com`,

  // Name of the Firebase Realtime Database
  database_name: `smm-panel-bot`,

  // API KEY from oxapay.com for merchant
  oxapay_merchant_key: `B1PHR3-MMKBP8-L09NSS-LDW0PC`,

  // API KEY from smmstone.com
  smmstone_key: `f63dc35896a466143598044084c20a8f`,

  // API KEY from rapidseen.net
  rapidseen_api: `64CSjX9yvqhzXUNUdlL9cj6hA7itno`
};
